
import { Col, Row } from 'react-bootstrap';
import { usePageTitle } from '../../hooks';
 
 
const Cour = () => {
     
     usePageTitle({
         title: '',
         breadCrumbItems: [
             {
                 path: '/Cour',
                 label: 'Cour',
                 active: true,
             },
         ],
     });

    return (
        <>
         <section>
            <Row>
                <div className='top-container dark-background'>
                    <div className='class="dark-background-inner-position-container"'>
                        
                    </div>
                </div>
            </Row>
         </section>

        

        </>
    );
};

export default Cour;
