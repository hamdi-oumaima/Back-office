import React from "react";
import  "../../css/style.css"
import  "../../lib/animate/animate.min.css"
import  "../../lib/owlcarousel/assets/owl.carousel.min.css"
import  "../../lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css"
import  "../../css/bootstrap.min.css"
import "../../css/styleHome.css"


const CourseCard = (props) => {
  const { imgUrl, title, lesson, students, rating } = props.item;

  return (
    <div className="single__course__item">
      {/* <div className="course__img">
        <img src={imgUrl} alt="" className="w-100" />
      </div> */}

   <div class="col-lg-11 col-md-1 wow fadeInUp" data-wow-delay="0.1s">
              <div className="team-item position-relative rounded overflow-hidden">
              <div className="overflow-hidden">
              <img src={imgUrl} alt="" className="w-100 mt-5" />
              </div>
              <div class="team-text bg-light text-center p-4">
                 <h6 className="course__title mb-4">{title}</h6>
              {/* <p className="text-primary">Department</p> */}
              <div className="team-social text-center">
              <a className="btn btn-square" href=""> <i className="fab fa-facebook-f"></i> </a> 
              <a className="btn btn-square" href=""> <i class="fab fa-twitter"></i> </a> 
              <a className="btn btn-square" href=""> <i class="fab fa-instagram"></i></a>
                 </div>
                  </div>
                  </div>
                  </div> 



    {/* <div className="course__details">
      <h6 className="course__title mb-4">{title}</h6> 

        <div className=" d-flex justify-content-between align-items-center">
          <p className="lesson d-flex align-items-center gap-1">
            <i class="ri-book-open-line"></i> {lesson} Lessons
          </p>

          <p className="students d-flex align-items-center gap-1">
            <i class="ri-user-line"></i> {students}K
          </p>
        </div>

        <div className=" d-flex justify-content-between align-items-center">
          <p className="rating d-flex align-items-center gap-1">
            <i class="ri-star-fill"></i> {rating}K
          </p>

          <p className="enroll d-flex align-items-center gap-1">
            <a href="#"> Enroll Now</a>
          </p>
        </div>
      </div>  */}
    </div>
  );
};

export default CourseCard;
