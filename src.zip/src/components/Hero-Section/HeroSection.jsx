import React from "react";

import { Container, Row, Col } from "reactstrap";
import heroImg from "../../assets/images/hero-img1.png";
import "./hero-section.css";
import Imgheader from "../../assets/images/bg-header1.png";

const HeroSection = () => {
  return (
    <section>
      <Row>
        <div className="titreHeader col-6">
        <h2 className="titre">Cours</h2>
        <p>Nous proposons actuellement plus de 300 cours à distance couvrant un large éventail de sujets.
          Vous pouvez trouver toutes les catégories et sous-catégories ci-dessous.</p>
          </div>
        <img src={Imgheader} alt="" className="bgheader" />
        {/* <div class="category-usps__text">
<div className="category-usps__header header2"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Plus de 250 cours à distance</font></font></div>
<div className="category-usps__text"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Explorez une variété de nouveaux cours d'auto-apprentissage.</font></font></div>
</div> */}
        
        <Row>
          <Col lg="6" md="6">
            
            <div className="hero__content">
         
             <h2 className="mb-4 hero__title">
               Notre Mission
              </h2>
              
              <p className="heroPara mb-5">
                Nous aspirons à fournir les meilleurs services à nos client,<br /> à leur offrir le plus
                haut niveau d'étude et de développement <br /> dans le monde.
              </p>
            </div>
            {/* <div className="search">
              <input type="text" placeholder="Search" />
              <button className="btn"><strong>Search</strong></button>
            </div> */}
          </Col>

          <Col lg="6" md="6">
            <img src={heroImg} alt="" className="w-100 hero__img" />
          </Col>
        </Row>
      </Row>
    </section>
  );
};

export default HeroSection;
