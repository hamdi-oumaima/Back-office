import React from 'react';
import { Collapse } from 'react-bootstrap';
import classNames from 'classnames';

// helpers
import { getHorizontalMenuItems } from '../../helpers/menu';

// components
import AppMenu from './Menu';

type NavbarProps = {
    isMenuOpened?: boolean;
};

const Navbar = ({ isMenuOpened }: NavbarProps) => {
    return (
        <div className="topnav">
            <div className="container-fluid">
                <nav className={classNames('navbar', 'navbar-expand-lg', 'topnav-menu', 'navbar-light')}>
                    <Collapse in={isMenuOpened} className="navbar-collapse">
                        <div id="topnav-menu-content">
                            <AppMenu menuItems={getHorizontalMenuItems()} />
                        </div>
                    </Collapse>
                </nav>
            </div>
        </div>
    );
};

export default Navbar;



// import React from 'react';
// import { Collapse } from 'react-bootstrap';
// import classNames from 'classnames';
// import Button from 'react-bootstrap/Button';

// // helpers
// import { getHorizontalMenuItems } from '../../helpers/menu';

// // components
// import AppMenu from './Menu';

// type NavbarProps = {
//     isMenuOpened?: boolean;
// };

// const Navbar = ({ isMenuOpened }: NavbarProps) => {
//     return (
//         <div>
//              <div className={classNames('row', 'bg-white')} >
//             <div className={classNames('logo col-md-2')}>
// <p><span>Tri-Web</span></p>                    
//                 </div>
//                 <nav className={classNames('navbar', 'navbar-expand-lg', 'topnav-menu', 'navbar-light','col-md-6')}>
//                     <Collapse in={isMenuOpened} className="navbar-collapse">
//                         <div id="topnav-menu-content">
//                             <AppMenu menuItems={getHorizontalMenuItems()} />
//                         </div>
//                     </Collapse>
//                 </nav>
        
//             <div  className={classNames('col-md-4','spcbtn')}>

//                 <Button className={classNames('BoutNave')} variant="light">Se connectre</Button>
//                 <Button className={classNames('BoutNave')} variant="dark">Sinscrire</Button>    
              
//             </div> 
           
           

               {/* <div className="btn-spec" col-md-2>              
                      <button>Se connecter</button>                    
                </div>
                <div className="btn-spec">     
                <button>S'inscrire</button> 
                </div> */}
            {/* // {classNames('col-md-2 d-flex justify-content-end  align-items-center')} */}

//         </div>
//         </div>
//     );
// };

// export default Navbar;