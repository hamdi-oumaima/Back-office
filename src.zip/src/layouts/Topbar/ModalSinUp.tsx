import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { Modal, Row, Col, Button } from 'react-bootstrap';
import * as yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import { EventInput } from '@fullcalendar/core';
import { FormInput } from '../../components/form';
import logoDark from '../../assets/images/logo-dark.png';
import { Link } from 'react-router-dom';
// components

type ModalSinUpProps = {
    isOpen?: boolean;
    onClose?: () => void;
  
};

const ModalSinUp = ({
    isOpen,
    onClose,
    
}: ModalSinUpProps) => {
     

    // const methods = useForm({ defaultValues: event });
    // const {
    //     handleSubmit,
    //     register,
    //     control,
    //     formState: { errors },
    // } = methods;

    // handle form submission
    const onSubmitEvent = (data: EventInput) => {
     //   isEditable ? onUpdateEvent(data) : onAddEvent(data);
    };
    return (
        <Modal show={isOpen} onHide={onClose}>
            <Modal.Header className="py-3 px-4 border-bottom-0" closeButton>
                <Modal.Title as="h5" id="modal-title">
                    {/* {isEditable ? 'Edit Event' : 'Add New Event'} */}
                    test modal
                </Modal.Title>
            </Modal.Header>
            <Modal.Body className="px-4 pb-4 pt-0">
           
                        <div className="text-center mt-2 mb-4">
                            <div className="auth-logo">
                                <Link to="/" className="logo logo-dark">
                                    <span className="logo-lg">
                                        <img src={logoDark} alt="" height="24" />
                                    </span>
                                </Link>

                                <Link to="/" className="logo logo-light">
                                    <span className="logo-lg">
                                        <img src={logoDark} alt="" height="24" />
                                    </span>
                                </Link>
                            </div>
                        </div>
                        <form className="ps-3 pe-3">
                            <div className="mb-3">
                                <label htmlFor="username" className="form-label">
                                    Name
                                </label>
                                <input
                                    className="form-control"
                                    type="email"
                                    id="username"
                                    required
                                    placeholder="Michael Zenaty"
                                />
                            </div>

                            <div className="mb-3">
                                <label htmlFor="emailaddress" className="form-label">
                                    Email address
                                </label>
                                <input
                                    className="form-control"
                                    type="email"
                                    id="emailaddress"
                                    required
                                    placeholder="john@deo.com"
                                /> 
                            </div>

                            <div className="mb-3">
                                <label htmlFor="password" className="form-label">
                                    Password
                                </label>
                                <input
                                    className="form-control"
                                    type="password"
                                    required
                                    id="password"
                                    placeholder="Enter your password"
                                />
                            </div>

                            <div className="mb-3">
                                <div className="form-check">
                                    <input type="checkbox" className="form-check-input" id="customCheck1" />
                                    <label className="form-check-label" htmlFor="customCheck1">
                                        I accept <Link to="#">Terms and Conditions</Link>
                                    </label>
                                </div>
                            </div>

                            <div className="mb-3 text-center">
                                <button className="btn btn-primary" type="submit">
                                    Sign Up Free
                                </button>
                            </div>
                        </form>
                    



            </Modal.Body>
        </Modal>
    );
};

export default ModalSinUp;
