export type Contact = {
    id: number;
    avatar: string;
    shortDesc: string;
    name: string;
    mobile: string;
    email: string;
    location: string;
};
