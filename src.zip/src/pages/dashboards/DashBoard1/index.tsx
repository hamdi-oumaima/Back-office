
import { Col, Row } from 'react-bootstrap';

// hooks
import { usePageTitle } from '../../../hooks';

// component
// import Statistics from './Statistics';
// import SalesChart from './SalesChart';
// import StatisticsChart from './StatisticsChart';
// import RevenueChart from './RevenueChart';
// import Users from './Users';
// import Inbox from './Inbox';
// import Projects from './Projects';

// dummy data
import { messages, projectDetails } from './data';
import HeroSection from '../../../components/Hero-Section/HeroSection';
import AboutUs from '../../../components/About-us/AboutUs';
import Feature from '../../../components/Feature-section/Features';
import Company from '../../../components/Company-section/Company';
import Courses from '../../../components/Courses-section/Courses';
import ChooseUs from '../../../components/Choose-us/ChooseUs';
import Newsletter from '../../../components/Newsletter/Newsletter';
import Footer from '../../../components/Footer/Footer';
import FreeCourse from '../../../components/Free-course-section/FreeCourse';
import Testimonials from '../../../components/Testimonial/Testimonials';

const DashBoard1 = () => {
    // set pagetitle
    // usePageTitle({
    //     title: '',
    //     breadCrumbItems: [
    //         {
    //             path: '/dashboard',
    //             label: 'DashBoard',
    //             active: true,
    //         },
    //     ],
    // });

    return (
        <>
         

            <HeroSection/>
            <Feature/>
            <AboutUs/>
            {/* <Company/> */}
           <Courses/>
           <ChooseUs/>
           <FreeCourse/>
           <Testimonials/> 
           <Newsletter/>
           <Footer/>




            {/* <Statistics />  */}

            {/* <Row>
                <Col xl={4}>
                    <SalesChart />
                </Col>
                <Col xl={4}>
                    <StatisticsChart />
                </Col>
                <Col xl={4}>
                    <RevenueChart />
                </Col>
            </Row> */}

            {/* <Users /> */}

            {/* <Row>
                <Col xl={4}>
                    <Inbox messages={messages} />
                </Col>
                <Col xl={8}>
                    <Projects projectDetails={projectDetails} />
                </Col>
            </Row> */}
        </>
    );
};

export default DashBoard1;
