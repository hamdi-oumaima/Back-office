export type MdiIcon = {
    name: string;
    hex: string;
    version: string;
    deprecated?: boolean;
};
