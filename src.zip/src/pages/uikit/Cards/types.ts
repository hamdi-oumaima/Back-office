export type CardGroupItem = {
    id: number;
    image: string;
    title: string;
    text: string;
    subtext: string;
};
