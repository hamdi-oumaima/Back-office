export type Variant = 'primary' | 'secondary' | 'success' | 'info' | 'warning' | 'danger';
