export type Variant =
    | 'primary'
    | 'secondary'
    | 'success'
    | 'danger'
    | 'warning'
    | 'info'
    | 'pink'
    | 'blue'
    | 'light'
    | 'dark';
