export type Tnode = {
    id: number;
    text: string;
    children?: Tnode[];
};
